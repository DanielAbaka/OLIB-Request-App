# -*- coding: utf-8 -*-
{
    'name': 'ORANGE CALL CENTER REQUEST MODULE',
    'summary': "This module will allow an employee to record customer details",
    'version': '11.0.0.0.1',
    'author': 'Daniel Abaka',
    'company': 'Orange Liberia',
    'website': 'https://www.orange.com.lr',
    'category': 'Tools',
    'depends': ['base','hr','mail'],
    'license': 'AGPL-3',
    'data': [

        'security/group.xml',  
        'data/call_center_mail_template.xml',
        'views/call_center_request_view.xml',
        'views/call_center_request_report_view.xml',
        'views/group_action_validation_view.xml',
        'security/ir.model.access.csv',
        
        
    ],
    'demo': [],
    'installable': True,
    'auto_install': False,
    'application': True,
}
