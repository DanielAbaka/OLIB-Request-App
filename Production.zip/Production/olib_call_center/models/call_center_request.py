# -*- coding: utf-8 -*-
import requests
from datetime import datetime
from odoo import models, fields, api
# from odoo.exceptions import Warning
from odoo.exceptions import ValidationError

#CALL CENTER REQUEST CLASS
class CallCenterRequestPin(models.Model):
    
    _name = "call.center.request.pin"
    _description = 'Call Center Request'
    _inherit = 'mail.thread'
    _rec_name = "request_no"


    # REQUEST NUMBER SEQUENCE CODE STARTS HERE
    @api.model
    def create(self, vals):
       if vals.get('request_no', 'New') == 'New':
           vals['request_no'] = self.env['ir.sequence'].next_by_code(
               'call.center.request.pin') or 'New'
       result = super(CallCenterRequestPin, self).create(vals)
       return result

    # REQUEST NUMBER SEQUENCE CODE END HERE

    # CALL CENTER CREATE REQUEST CODE STARTS HERE
    state = fields.Selection([('new', 'NEW'),('callcenter', 'Call Center'), ('ombackoffice', 'OM Back Office'),('pinreset', 'PIN RESET'),('unblock', 'UNBLOCK'),('invalid', 'INVALID'),
                            ], default='new')
    request_no = fields.Char(string='Request Number', readonly=True, required=True, copy=False, default='New')
    current_user = fields.Many2one('res.users','Agent Name', default=lambda self: self.env.uid, readonly="True", track_visibility='always')
    phone = fields.Char(related='current_user.phone', string='Mobile', readonly="True") 
    email = fields.Char(related='current_user.email', string='Email', readonly="True")
    function = fields.Char(related='current_user.function', string='Position', readonly="True")
    date = fields.Datetime(string='Created Date', default=lambda *a: datetime.now(),readonly=True)
    customer_number = fields.Char(string='Customer Number', required=True)
    fullname = fields.Char(string='Customer Name', required=True)
    id_type = fields.Many2one('callcenter.group.validation', string='ID Type', required=True)
    om_last_trans_date = fields.Date(string='Last Trans Date OM', required=True)

    # OM LAST TRANSACTION DATE VALIDATION CODE STARTS HERE
    @api.one
    @api.constrains('om_last_trans_date')
    def _check_date_om_last_trans_date(self):
        if self.om_last_trans_date:
             if datetime.strptime(self.om_last_trans_date, "%Y-%m-%d").date() > datetime.now().date():
                raise ValidationError('FUTURE DATE IS NOT ACCEPTABLE FOR ORANGE MONEY LAST TRANSACTION')
    # OM LAST TRANSACTION DATE VALIDATION CODE END HERE

    # GSM LAST TRANSACTION DATE VALIDATION CODE STARTS HERE
    gsm_last_trans_date = fields.Date(string='Last Trans Date GSM', required=True)
    @api.one
    @api.constrains('gsm_last_trans_date')
    def _check_date_gsm_last_trans_date(self):
        if self.gsm_last_trans_date:
             if datetime.strptime(self.gsm_last_trans_date, "%Y-%m-%d").date() > datetime.now().date():
                raise ValidationError('FUTURE DATE IS NOT ACCEPTABLE FOR GSM LAST TRANSACTION')
    # GSM LAST TRANSACTION DATE VALIDATION CODE END HERE

    # DATE OF BIRTH DATE VALIDATION CODE STARTS HERE
    dateofbirth = fields.Date(string='Date Of Birth', required=True)
    @api.one
    @api.constrains('dateofbirth')
    def _check_date_dateofbirthe(self):
        if self.dateofbirth:
             if datetime.strptime(self.dateofbirth, "%Y-%m-%d").date() > datetime.now().date():
                raise ValidationError('FUTURE DATE IS NOT ACCEPTABLE FOR DATE OF BIRTH')
    # DATE OF BIRTH DATE VALIDATION CODE END HERE

    sim_status = fields.Many2one('group.validation', string='Sim Status', required=True)
    usd_amount = fields.Float(string='OM Wallet Blc USD', required=True)
    lrd_amount = fields.Float(string='OM Wallet Blc LRD', required=True)

    # 200$ VALIDATION THRESHOLD TO REDIRECT CUSTOMER TO STORE OR POS CODE STARTS HERE
    @api.one
    @api.constrains('usd_amount','lrd_amount')
    def _check_threshold_amount(self):
        if self.usd_amount > 200.00 or self.lrd_amount > 40000.00:
            raise ValidationError('Hello, This Customer have exceeded 200$ to RESET or UNBLOCK PIN. Please sent this customer to any Orange Stores or POS for Help thanks.')
    # 200$ VALIDATION THRESHOLD TO REDIRECT CUSTOMER TO STORE OR POS CODE ENDS HERE


    gsm_account_type = fields.Selection([('gsm_usd','USD GSM'),('gsm_lrd','LRD GSM')], string='GSM Wallet Type', required=True, default='gsm_usd')
    gsm_usd_balance = fields.Float(string='GSM Wallet Blc USD', required=True)
    gsm_lrd_balance = fields.Float(string='GSM Wallet Blc LRD', required=True)
    comment = fields.Text(string='Reason', required=True)

    # CALL CENTER CREATE REQUEST CODE END HERE

    # BACK-OFFICE SMS VALIDATION CODE STARTS HERE
    group_phone_one = fields.Char(related='sim_status.group_phone_one' ,string="Mobile 1", required=True)
    group_phone_two = fields.Char(related='sim_status.group_phone_two', string="Mobile 2")
    group_phone_three = fields.Char(related='sim_status.group_phone_three', string="Mobile 3")
    group_phone_four = fields.Char(related='sim_status.group_phone_four', string="Mobile 4")
    group_phone_five = fields.Char(related='sim_status.group_phone_five', string="Mobile 5")
    group_phone_six = fields.Char(related='sim_status.group_phone_six', string="Mobile 6")
    group_phone_seven = fields.Char(related='sim_status.group_phone_seven', string="Mobile 7")
    group_phone_eight = fields.Char(related='sim_status.group_phone_eight', string="Mobile 8")
    group_phone_nine = fields.Char(related='sim_status.group_phone_nine', string="Mobile 9")
    group_phone_ten = fields.Char(related='sim_status.group_phone_ten', string="Mobile 10")
    group_email = fields.Char(related='sim_status.group_email', string="Group Email")
    # BACK-OFFICE SMS VALIDATION CODE END HERE

    # CALL-CENTER SMS VALIDATION CODE STARTS HERE
    c_group_phone_one = fields.Char(related='id_type.c_group_phone_one' ,string="Number 1", required=True)
    c_group_phone_two = fields.Char(related='id_type.c_group_phone_two', string="Number 2")
    c_group_phone_three = fields.Char(related='id_type.c_group_phone_three', string="Number 3")
    c_group_phone_four = fields.Char(related='id_type.c_group_phone_four', string="Number 4")
    c_group_phone_five = fields.Char(related='id_type.c_group_phone_five', string="Number 5")
    c_group_phone_six = fields.Char(related='id_type.c_group_phone_six', string="Number 6")
    c_group_phone_seven = fields.Char(related='id_type.c_group_phone_seven', string="Number 7")
    c_group_phone_eight = fields.Char(related='id_type.c_group_phone_eight', string="Number 8")
    c_group_phone_nine = fields.Char(related='id_type.c_group_phone_nine', string="Number 9")
    c_group_phone_ten = fields.Char(related='id_type.c_group_phone_ten', string="Number 10")
    c_group_phone_eleven = fields.Char(related='id_type.c_group_phone_eleven', string="Number 11")
    c_group_phone_twelve = fields.Char(related='id_type.c_group_phone_twelve', string="Number 12")
    c_group_phone_thirteen = fields.Char(related='id_type.c_group_phone_thirteen', string="Number 13")
    c_group_phone_fourteen = fields.Char(related='id_type.c_group_phone_fourteen', string="Number 14")
    c_group_phone_fifteen = fields.Char(related='id_type.c_group_phone_fifteen', string="Number 15")
    c_group_email = fields.Char(related='id_type.c_group_email', string="Group Email")
    # CALL-CENTER SMS VALIDATION CODE END HERE

    # BACK-OFFICE ACCEPT REQUEST CODE STARTS HERE
    accepted_by = fields.Many2one('res.users','Accepted By', readonly="True")
    valid_date =fields.Datetime(string="Accepted Date", readonly="True") 
    cu_name = fields.Selection([('correct_name','Correct'), ('incorrect_name','Incorrect')], string="Customer Name")
    cu_number = fields.Selection([('correct_number','Correct'),('incorrect_number','Incorrect')], string="Customer Number")
    cu_id_type = fields.Selection([('correct_id','Correct'),('incorrect_id','Incorrect')], string="ID Type")
    cu_dob = fields.Selection([('correct_dob','Correct'),('incorrect_dob','Incorrect')], string="Date of Birth")
    valid_reason =fields.Text(string="Comment")
    # BACK-OFFICE ACCEPT REQUEST CODE END HERE

    # BACK-OFFICE REJECT REQUEST CODE STARTS HERE
    rejected_by = fields.Many2one('res.users','Rejected By', readonly="True")
    invalid_opinion = fields.Selection([('INVALID', 'INVALID')],default='INVALID', string='Opinion', readonly="True")
    invalid_date =fields.Datetime(string="Rejected Date", readonly="True") 
    invalid_reason =fields.Text(string="Comment")
    # BACK-OFFICE REJECT REQUEST CODE END HERE

    # CALL-CENTER RESET PIN REQUEST CODE STARTS HERE
    reset_by = fields.Many2one('res.users','Reset By', readonly="True")
    reset_date =fields.Datetime(string="Reset Date", readonly="True") 
    reset_comment =fields.Text(string="Comment")
    # CALL-CENTER RESET PIN REQUEST CODE END HERE

    # CALL-CENTER UNBLOCK PIN REQUEST CODE STARTS HERE
    unblock_by = fields.Many2one('res.users','Unblock By', readonly="True")
    unblock_date =fields.Datetime(string="Unblock Date",  readonly="True") 
    unblock_comment =fields.Text(string="Comment")
    # CALL-CENTER UNBLOCK PIN REQUEST CODE END HERE



    # CALL-CENTER RESET PIN BUTTON REQUEST CODE STARTS HERE
    @api.multi
    def button_call_center_pin_reset(self):
        for record in self:
            record.write({'state': 'pinreset'})
    # CALL-CENTER RESET PIN BUTTON REQUEST CODE END HERE

    # CALL-CENTER RESET PIN THRESHOLD CODE STARTS HERE            
        usd_amount=record["usd_amount"]
        lrd_amount=record["lrd_amount"]
        if usd_amount > 20.00 or lrd_amount > 4000.00:
                raise ValidationError('Hello! This Customer have exceeded the threshold to RESET PIN, Please submit to Back-Office now!')
    # CALL-CENTER RESET PIN THRESHOLD CODE END HERE 

    # CALL-CENTER UNBLOCK PIN BUTTON REQUEST CODE STARTS HERE
    @api.multi
    def button_call_center_unblock(self):
        for record in self:
            record.write({'state': 'unblock'})
    # CALL-CENTER UNBLOCK PIN BUTTON REQUEST CODE END HERE
    
    # CALL-CENTER UNBLOCK PIN THRESHOLD CODE STARTS HERE
        usd_amount=record["usd_amount"]
        lrd_amount=record["lrd_amount"]
        if usd_amount > 20.00 or lrd_amount > 4000.00:
                raise ValidationError('Hello! This Customer have exceeded the threshold to RESET PIN, Please submit to Back-Office now!')
   
    @api.multi
    def button_submit_back_office(self):
        for record in self:
            record.write({'state': 'ombackoffice'})
            
    # CALL-CENTER SUBMIT REQUEST TO BACK OFFICE EMAIL CODE END HERE 

    # CALL-CENTER SUBMIT REQUEST TO BACK OFFICE SMS CODE STARTS HERE
            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)
            group_phone_one=record["group_phone_one"]
            group_phone_two=record["group_phone_two"]
            group_phone_three=record["group_phone_three"]
            group_phone_four=record["group_phone_four"]
            group_phone_five=record["group_phone_five"]
            group_phone_six=record["group_phone_six"]
            group_phone_seven=record["group_phone_seven"]
            group_phone_eight=record["group_phone_eight"]
            group_phone_nine=record["group_phone_nine"]
            group_phone_ten=record["group_phone_ten"]
            customer_number=record["customer_number"]
            phone=record["phone"]
            requester_name = str(self.current_user.name)
            request_no=record["request_no"]
            
           
            sendSMS([group_phone_one],"Hello "+requester_name+" has made a Orange Money Request "+request_no+" Pending your approval, Please Login to process the request.")
            sendSMS([group_phone_two],"Hello "+requester_name+" has made a Orange Money Request "+request_no+" Pending your approval, Please Login to process the request.")
            sendSMS([group_phone_three],"Hello "+requester_name+" has made a Orange Money Request "+request_no+" Pending your approval, Please Login to process the request.")
            sendSMS([group_phone_four],"Hello "+requester_name+" has made a Orange Money Request "+request_no+" Pending your approval, Please Login to process the request.")
            sendSMS([group_phone_five],"Hello "+requester_name+" has made a Orange Money Request "+request_no+" Pending your approval, Please Login to process the request.")
            sendSMS([group_phone_six],"Hello "+requester_name+" has made a Orange Money Request "+request_no+" Pending your approval, Please Login to process the request.")
            sendSMS([group_phone_seven],"Hello "+requester_name+" has made a Orange Money Request "+request_no+" Pending your approval, Please Login to process the request.")
            sendSMS([group_phone_eight],"Hello "+requester_name+" has made a Orange Money Request "+request_no+" Pending your approval, Please Login to process the request.")
            sendSMS([group_phone_nine],"Hello "+requester_name+" has made a Orange Money Request "+request_no+" Pending your approval, Please Login to process the request.")
            sendSMS([group_phone_ten],"Hello "+requester_name+" has made a Orange Money Request "+request_no+" Pending your approval, Please Login to process the request.")
            sendSMS([customer_number],"Dear customer your request is under review by our TEAM, afterward YOUR PIN will be RESET in 24hrs if information provided is VALID. Thanks for choosing Orange.")
            sendSMS([phone],"Hello your Orange Money request has been submitted to Back Office successfully thank you!.")
    
    # CALL-CENTER SUBMIT REQUEST TO BACK OFFICE SMS CODE END HERE



#BACK-OFFICE APPROVE REQUEST CLASS
class ValidRequestBackOffice(models.Model):
    _name = "valid.request.backoffice"

    # BACK-OFFICE ACCEPT REQUEST CODE STARTS HERE
    accepted_by = fields.Many2one('res.users','Accepted By', default=lambda self: self.env.uid, readonly="True", track_visibility='always')
    valid_date =fields.Datetime(string="Accepted Date", default=lambda *a: datetime.now(), readonly="True") 
    cu_name = fields.Selection([('correct_name','Correct'), ('incorrect_name','Incorrect')], string="Customer Name", required=True)
    cu_number = fields.Selection([('correct_number','Correct'),('incorrect_number','Incorrect')], string="Customer Number", required=True)
    cu_id_type = fields.Selection([('correct_id','Correct'),('incorrect_id','Incorrect')], string="ID Type", required=True)
    cu_dob = fields.Selection([('correct_dob','Correct'),('incorrect_dob','Incorrect')], string="Date of Birth", required=True)
    valid_reason =fields.Text(string="Comment", required=True)
    # BACK-OFFICE ACCEPT REQUEST CODE END HERE

    # BACK-OFFICE SUBMIT VALID REQUEST CODE STARTS HERE
    @api.multi
    def button_submit_valid(self):
        if self.env.context.get('request_id'):
            request = self.env['call.center.request.pin'].browse(self.env.context.get('request_id'))
            request.write({'state': 'callcenter', 'accepted_by': self.accepted_by.id, 'valid_date': self.valid_date,'cu_name': self.cu_name,'cu_number': self.cu_number,'cu_id_type': self.cu_id_type,'cu_dob': self.cu_dob,'valid_reason': self.valid_reason})
    # BACK-OFFICE SUBMIT VALID REQUEST CODE STARTS HERE

    # BACK-OFFICE SUBMIT VALID REQUEST SMS CODE STARTS HERE
            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)
            field="c_group_phone_one"
            c_group_phone_one=request[field]

            field="c_group_phone_two"
            c_group_phone_two=request[field]

            field="c_group_phone_three"
            c_group_phone_three=request[field]

            field="c_group_phone_four"
            c_group_phone_four=request[field]

            field="c_group_phone_five"
            c_group_phone_five=request[field]

            field="c_group_phone_six"
            c_group_phone_six=request[field]

            field="c_group_phone_seven"
            c_group_phone_seven=request[field]

            field="c_group_phone_eight"
            c_group_phone_eight=request[field]

            field="c_group_phone_nine"
            c_group_phone_nine=request[field]

            field="c_group_phone_ten"
            c_group_phone_ten=request[field]

            field="c_group_phone_eleven"
            c_group_phone_eleven=request[field]

            field="c_group_phone_twelve"
            c_group_phone_twelve=request[field]

            field="c_group_phone_three"
            c_group_phone_thirteen=request[field]

            field="c_group_phone_fourteen"
            c_group_phone_fourteen=request[field]

            field="c_group_phone_fifteen"
            c_group_phone_fifteen=request[field]

            accepted_name = str(self.accepted_by.name)
            field="request_no"
            request_no=request[field]

            field="phone"
            phone=request[field]
            
           
            sendSMS([phone],"Hello, "+accepted_name+" has accepted your Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_one],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_two],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_three],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_four],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_five],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_six],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_seven],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_eight],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_nine],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_ten],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_eleven],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_twelve],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_three],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_fourteen],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
            sendSMS([c_group_phone_fifteen],"Hello "+accepted_name+" has accepted Orange Money Ticket "+request_no+" Request, Please login to close the ticket request.")
    # BACK-OFFICE SUBMIT VALID REQUEST SMS CODE STARTS HERE


#BACK OFFICE REJECT REQUEST CLASS
class InvalidRequestBackOffice(models.Model):
    _name = "invalid.request.backoffice"


    rejected_by = fields.Many2one('res.users','Rejected By', default=lambda self: self.env.uid, readonly="True")
    invalid_opinion = fields.Selection([('INVALID', 'INVALID')],default='INVALID', string='Opinion', readonly="True")
    invalid_date =fields.Datetime(string="Rejected Date", default=lambda *a: datetime.now(), readonly="True") 
    invalid_reason =fields.Text(string="Comment", required=True) 

    @api.multi
    def button_submit_invalid(self):
        if self.env.context.get('request_id'):
            request = self.env['call.center.request.pin'].browse(self.env.context.get('request_id'))
            request.write({'state': 'invalid', 'rejected_by': self.rejected_by.id, 'invalid_opinion': self.invalid_opinion,'invalid_date': self.invalid_date,'invalid_reason': self.invalid_reason})

            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)

            rejected_name = str(self.rejected_by.name)
            field="request_no"
            request_no=request[field]

            field="phone"
            phone=request[field]

            field="customer_number"
            customer_number=request[field]

            sendSMS([phone],"Hello, Your Orange Money Ticket "+request_no+" Request is Invalid and has been rejected by "+rejected_name+" thanks")
            sendSMS([customer_number],"Dear customer your information provided is INVALID, Please visit our nearby STORES or POS for help. Thanks for choosing Orange.")


#CALL CENTER RESET PIN REQUEST CLASS
class CallCenterRequestPinReset(models.Model):
    _name = "callcenter.request.pinreset"

    reset_by = fields.Many2one('res.users','Reset By', default=lambda self: self.env.uid, readonly="True")
    reset_date =fields.Datetime(string="Reset Date", default=lambda *a: datetime.now(), readonly="True")
    reset_comment =fields.Text(string="Comment", required=True)



    # @api.depends('start_date','end_date')
    # def get_hours(self):
    #     seconds = (self.end_date - self.start_date).total_seconds()
    #     self.total_hours = seconds // 3600

    # start_date =fields.Datetime(string="Start Date")
    # end_date =fields.Datetime(string="End Date")
    # total_hours = fields.Integer("Total Hours", compute="get_hours", store=True) 




    @api.multi
    def button_submit_request_pinreset_action(self):
        if self.env.context.get('request_id'):
            request = self.env['call.center.request.pin'].browse(self.env.context.get('request_id'))
            request.write({'state': 'pinreset', 'reset_by': self.reset_by.id, 'reset_date': self.reset_date,'reset_comment': self.reset_comment})
 
            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)

            field="customer_number"
            customer_number=request[field]

            sendSMS([customer_number],"Dear customer your PIN has successfully RESET, Dial *144# and follow the instructions. Thanks for choosing Orange.")


#CALL CENTER UNBLOCK PIN REQUEST CLASS
class CallCenterRequestUnblock(models.Model):
    _name = "callcenter.request.unblock"


    unblock_by = fields.Many2one('res.users','Unblock By', default=lambda self: self.env.uid, readonly="True")
    unblock_date =fields.Datetime(string="Unblock Date", default=lambda *a: datetime.now(), readonly="True") 
    unblock_comment =fields.Text(string="Comment", required=True)

    @api.multi
    def button_submit_request_unblock_action(self):
        if self.env.context.get('request_id'):
            request = self.env['call.center.request.pin'].browse(self.env.context.get('request_id'))
            request.write({'state': 'unblock', 'unblock_by': self.unblock_by.id, 'unblock_date': self.unblock_date,'unblock_comment': self.unblock_comment})

            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)

            field="customer_number"
            customer_number=request[field]

            sendSMS([customer_number],"Dear customer your PIN has successfully UNBLOCK. Thanks for choosing Orange.")


#BACK OFFICE GROUP CLASS
class BackOfficeValidationGroup(models.Model):
    _name = 'group.validation'
    _rec_name = "group_name"

    group_name = fields.Char(string="Sim Status", required=True)
    group_phone_one = fields.Char(string="Mobile 1")
    group_phone_two = fields.Char(string="Mobile 2")
    group_phone_three = fields.Char(string="Mobile 3")
    group_phone_four = fields.Char(string="Mobile 4")
    group_phone_five = fields.Char(string="Mobile 5")
    group_phone_six = fields.Char(string="Mobile 6")
    group_phone_seven = fields.Char(string="Mobile 7")
    group_phone_eight = fields.Char(string="Mobile 8")
    group_phone_nine = fields.Char(string="Mobile 9")
    group_phone_ten = fields.Char(string="Mobile 10")
    group_email = fields.Char(string="Group Email")


#CALL CENTER GROUP CLASS
class CallCenterValidationGroup(models.Model):
    _name = 'callcenter.group.validation'
    _rec_name = "c_group_name"

    c_group_name = fields.Char(string="ID Type", required=True)
    c_group_phone_one = fields.Char(string="User 1")
    c_group_phone_two = fields.Char(string="User 2")
    c_group_phone_three = fields.Char(string="User 3")
    c_group_phone_four = fields.Char(string="User 4")
    c_group_phone_five = fields.Char(string="User 5")
    c_group_phone_six = fields.Char(string="User 6")
    c_group_phone_seven = fields.Char(string="User 7")
    c_group_phone_eight = fields.Char(string="User 8")
    c_group_phone_nine = fields.Char(string="User 9")
    c_group_phone_ten = fields.Char(string="User 10")
    c_group_phone_eleven = fields.Char(string="User 11")
    c_group_phone_twelve = fields.Char(string="User 12")
    c_group_phone_thirteen = fields.Char(string="User 13")
    c_group_phone_fourteen = fields.Char(string="User 14")
    c_group_phone_fifteen = fields.Char(string="User 15")
    c_group_email = fields.Char(string="Group Email")




#SMS API
class SMS(models.Model):
    _name = "sms"

    @api.multi
    def send_sms(employee_numbers, message_content):
        #_logger.info("Ping -c 1 192.168.15.21")
        # ping = os.system("ping  192.168.15.21")
        #_logger.info(ping)
        for recipient_number in employee_numbers:
            url="http://192.168.15.21:8091/CellcomAPIService"
            headers = {'content-type': 'application/soap+xml'}
            body ="\
            <s:Envelope xmlns:a='http://www.w3.org/2005/08/addressing' xmlns:s='http://www.w3.org/2003/05/soap-envelope'>\
              <s:Header>\
                <a:Action s:mustUnderstand='1'>http://tempuri.org/ISubscribers/SubscriberSendNotification</a:Action>\
                <a:MessageID>urn:uuid:3472a125-74f5-4914-865d-d1037d1dcbd8</a:MessageID>\
                <a:ReplyTo>\
                  <a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>\
                </a:ReplyTo>\
              </s:Header>\
              <s:Body>\
                <SubscriberSendNotification xmlns='http://tempuri.org/'>\
                  <c_subs_req xmlns:d4p1='http://schemas.datacontract.org/2004/07/CellcomAPILibrary' xmlns:i='http://www.w3.org/2001/XMLSchema-instance'>\
                    <d4p1:Client>wcf client tool</d4p1:Client>\
                    <d4p1:Password>h1$d/6Hf78(hg</d4p1:Password>\
                    <d4p1:UserName>HIS</d4p1:UserName>\
                    <d4p1:DestinationNumber>%s</d4p1:DestinationNumber>\
                    <d4p1:NotificationText>%s</d4p1:NotificationText>\
                    <d4p1:NotificationType>SMS</d4p1:NotificationType>\
                    <d4p1:OriginatingNumber>OM Request</d4p1:OriginatingNumber>\
                  </c_subs_req>\
                </SubscriberSendNotification>\
              </s:Body>\
            </s:Envelope>\
            " %(recipient_number, message_content)
            response = requests.post(url,data=body,headers=headers)
            #print(response.content)
            print("Recipient number is", recipient_number)
            return response

        return False