# -*- coding: utf-8 -*-

from . import test_mail_followers
from . import test_mail_message
from . import test_mail_features
from . import test_mail_channel
from . import test_mail_gateway
from . import test_message_read
from . import test_message_track
from . import test_mail_template
from . import test_invite
from . import test_ir_actions
from . import test_update_notification
from . import test_portal
from . import test_mail_activity
